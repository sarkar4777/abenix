"""AgentForge Code Runner UAT fixture.

Reads a JSON object {"a": int, "b": int} from stdin, returns
{"sum": a + b}.  Has no external deps — runs on the default Python
sandbox image without a requirements step.
"""
import json
import sys


def add(a: int, b: int) -> int:
    return a + b


def main() -> None:
    raw = sys.stdin.read().strip() or '{"a": 0, "b": 0}'
    payload = json.loads(raw)
    result = {"sum": add(int(payload.get("a", 0)), int(payload.get("b", 0)))}
    sys.stdout.write(json.dumps(result))


if __name__ == "__main__":
    main()
