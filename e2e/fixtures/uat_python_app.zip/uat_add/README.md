# UAT add-server

Tiny Python project used by the AgentForge Code Runner UAT.

* `python main.py` reads `{ "a": <int>, "b": <int> }` on stdin.
* Emits `{ "sum": <int> }` on stdout.
