import json, sys
data = json.load(sys.stdin)
raise ValueError('supplier list is missing the debt_to_equity column')
